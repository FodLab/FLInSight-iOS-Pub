//
//  FLInSight.h
//  FLInSight
//
//  Created by fodlab on 2020/1/16.
//  Copyright © 2020 fodlab. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FLInSight.
FOUNDATION_EXPORT double FLInSightVersionNumber;

//! Project version string for FLInSight.
FOUNDATION_EXPORT const unsigned char FLInSightVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FLInSight/PublicHeader.h>

#import <FLInSight/FLInSightSDK.h>


